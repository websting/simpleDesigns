# 🐕 Dog Sitter Template

A modern, responsive one-page HTML template designed for dog lovers and pet care professionals who want to promote their dog-sitting services online with style.

---

## 📸 Demo

**Live Preview:** [https://ahtml-dog-sitter.netlify.app/](https://ahtml-dog-sitter.netlify.app/)

![Dog Sitter Screenshot](/dist/assets/dog-sitter-screenshot.png)

---

## 🚀 Features

- 🐾 Smooth scrolling and fully responsive layout
- 💨 Styled with **Tailwind CSS 4.x**
- 🌅 Parallax scroll effects for visual appeal
- 🎯 Modern hero section with clear call-to-action buttons
- 🐶 High-impact backgrounds for better conversions
- 💌 Contact form design *(non-functional by default)*
- 📱 Mobile hamburger menu with smooth transitions
- 🛠️ Easy to customize and adapt to your brand

---

## 🧱 Tech Stack

- **HTML5**
- **Tailwind CSS**
- **JavaScript**
- **Unsplash** high-resolution photos

---

## 🛠️ Setup Instructions

1. **Unzip** the downloaded template folder.  
2. **Open a terminal** and navigate to the developer folder:
   ```bash
   cd dog-sitter
3. **Install dependencies**
   ```bash
   npm install

4. **Start the development server**
   ```bash
   npm run dev
   The site will open automatically at http://localhost:5173 (or a similar port).

5. **Build for production**
   ```bash
   npm run build
   This will generate a dist/ folder with optimized, production-ready files.

## 💡 Note:
The contact form is static and does not collect messages by default.
You can integrate it with Google Sheets, Netlify Forms, or your own backend if needed.

## 📁 Folder Structure Overview

Dog-Sitter-Template/
├── index.html              # Main landing page
├── public/
│   └── assets/             # Images and media files
├── src/                    # CSS and JavaScript source files
├── for-developers/         # Vite source version
└── for-non-developers/     # Ready-to-upload static version

## 📄 License

This template is provided under a Commercial Use License.
You may use and modify it for personal or client projects.
Resale, redistribution, or inclusion in other template bundles is not permitted.

### 👍 Credits

Designed and developed by AH for simpleDesigns
Placeholder images: Unsplash https://unsplash.com/
Image storage: Cloudinary https://cloudinary.com/
Icons: Font Awesome & Boxicons
https://fontawesome.com/
https://boxicons.com/

Designed and developed by AH for simpleDesigns — enjoy building your next project! 🐕
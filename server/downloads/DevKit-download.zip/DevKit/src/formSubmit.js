
// Form: Send Message button to google-sheet

// Insert your Google Script URL here.  (hint: ends with /exec)
const scriptURL = 'https://script.google.com/macros/s/AKfycbyWoMFF110TSk3d4PqvfFEPlxfheMA8-Zwk6R_85ZkKyoH9OCj5CLSGCDRAC-kSKcWn/exec'

            // Get the form element and the message element
            const form = document.forms['submit-to-google-sheet']
            const msg = document.getElementById('msg')
            
            // Add an event listener to the form's submit event
            form.addEventListener('submit', e => {
              e.preventDefault()
              fetch(scriptURL, { method: 'POST', body: new FormData(form)})
                .then(response => {
                    msg.innerHTML = 'Message Sent Successfully!'
                    setTimeout(function(){
                        msg.innerHTML = ''
                    },5000)
                    form.reset()
                })
                .catch(error => console.error('Error!', error.message))
            })

# 👋 DevKit — Modern Developer & Freelancer Portfolio Template

A modern, responsive HTML, CSS, and JavaScript starter template built with [Vite](https://vitejs.dev/). Perfect for software developers, UI engineers, freelancers, and tech creatives who want a fast, customizable online presence.

---

## 🔗 Live Demo

**[View Live Demo →](https://ahtml-portfolio.netlify.app/)**

---

## ⚡ Features

- 🔥 **Powered by Vite:** Built with Vite v6.2.6 for instant server start and lightning-fast builds.
- ⚙️ **Clean & Semantic:** Crafted with HTML5, modern CSS3, and lightweight Vanilla JavaScript.
- 📱 **Sections:** Includes Hero (with video background), About & Skills, Services, Projects      grid, and Contact.
- 🎨 **Modern Typography:** Styled with **Space Grotesk**, **Inter**, and **DM Serif Text** via Google Fonts.
- 💌 **Google Sheets Contact Form:** Pre-wired form handler in `script.js` ready to connect to your own Google Sheet.
- 🌐 **Deploy-Ready:** Optimized for Netlify, Vercel, GitHub Pages, or any static host.

---

## 📁 What's Included

```text
DevKit/
├── public/                 # Static assets (images, background video, CV PDF)
├── src/                    # Source code
│   ├── style.css           # Main stylesheet & mobile responsive rules
│   └── script.js           # Sidebar menu, smooth scroll & contact form logic
├── index.html              # Main HTML file with commented sections
├── vite.config.js          # Vite configuration
├── package.json            # Project dependencies and scripts
├── LICENSE                 # License file
└── README.md               # Documentation
```

---

## 🛠️ Getting Started

Make sure you have **Node.js** and **npm** installed on your machine: [Download Node.js](https://nodejs.org/).

### Installation & Development

1. **Unzip** the downloaded template folder.

2. **Open a terminal** inside the project folder:
   ```bash
   cd DevKit
   ```
3. **Install dependencies:**
   ```bash
   npm install
   ```
4. **Start the local development server:**
   ```bash
   npm run dev
   ```
   Open the local URL shown in your terminal (usually `http://localhost:5173`).

---

## ⚙️ Customization Guide

- **`index.html`:** Divided into clearly commented sections (`Header`, `Home`, `About`, `Services`, `Projects`, `Contact`) for quick text and image swaps.

- **`src/style.css`:** Contains color variables (`--main-color`, `--bg-color`), typography rules, card animations, and mobile responsive overrides at the bottom.

- **`src/script.js`:** Controls the mobile navigation drawer, active link highlights, and form submission feedback.

### 📂 Setting Up the Download CV Button

1. Place your resume PDF inside the `public/` folder (for example, `public/my-resume.pdf`).

2. Update the `href` attribute in `index.html`:
   ```html
   <a href="/my-resume.pdf" download class="btn btn2" id="down-cv">Download CV</a>
   ```

### 💌 Connecting the Contact Form (Google Sheets)
### How It Works:

- Background Sending: When someone clicks submit, the src/formSubmit.js file sends their info behind the scenes. The page stays put instead of reloading.

- Instant Confirmation: Once the message goes through, a "Success" note pops up inside the <span id="msg"></span> area on your webpage.


1. Build the Spreadsheet: Create a new Google Sheet with three column headers: Name, Email, and Message.

2. Create the Bridge: Use Google Apps Script (built right into Google Sheets) to create a special web link. This link acts as a bridge that catches the form data and writes it into your columns.

3. Connect Your Website: Open the src/formSubmit.js file in your project. Find the placeholder text called scriptURL and paste your new Google web link there.

---

## 🚀 Building for Production

When you are ready to deploy your portfolio, generate an optimized production build:

```bash
npm run build
```

This creates a `dist/` folder with minified, production-ready files ready to drag-and-drop onto **Netlify**, **Vercel**, or **GitHub Pages**.

---

## 📄 License

This template is provided under a **Commercial Use License**.
- ✅ **Allowed:** Use and modify for unlimited personal or client projects.
- ❌ **Not Allowed:** Resale, redistribution, or inclusion in other template bundles or marketplaces.

---

## 👍 Credits

- **Design & Development:** AH for simpleDesigns
- **Placeholder Photography:** [Unsplash](https://unsplash.com/)
- **Media Hosting:** [Cloudinary](https://cloudinary.com/)
- **Icons:** [Boxicons](https://boxicons.com/) & [Font Awesome](https://fontawesome.com/)

All placeholder content and media can be replaced with your own. Enjoy and happy coding! 🚀



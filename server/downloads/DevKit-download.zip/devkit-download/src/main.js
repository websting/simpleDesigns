// custome styles
import './style.css';
// media queries
import './responsive.css';
// sidebar menu logic
import './sidebar.js';
// Import form submission logic
import './formSubmit.js';
export default {
  content: ["./index.html", "./about.html", "./gallery.html", "./blog.html", "./contact.html", "./src/**/*.{js,html}"],
  theme: { extend: {} },
  plugins: [],
}

# Photographer Template

A modern, lightweight, and fully responsive website template built with **Vite**, **Tailwind CSS 4.x**, **HTML**, **CSS**, and **Vanilla JavaScript**.

Designed for photographers, creative studios, freelancers, agencies, and client portfolios.

### 🔗 Live Demo
[https://ahtml-photographer.netlify.app/](https://ahtml-photographer.netlify.app/)

## 🖼 Preview
![Homepage Preview](./public/screenshot.png)

---

## ✨ Features

- ⚡ **Vite-powered** fast development and optimized builds
- 🎨 **Tailwind CSS 4.x** utility-first styling
- 🎞️ **Infinite Hero Carousel** with touch swipe, hover pause, and animated captions
- 🖼️ **Masonry Gallery & Lightbox** with keyboard navigation (`Esc`, `←`, `→`) and slide transitions
- 💼 **Sessions & Packages** pricing cards and **Client Testimonials** layout
- 📝 **Dynamic Studio Journal (Blog)** powered by `src/blog.js` with Markdown-style formatting
- 📱 **Slide-Out Navigation Drawer** and responsive mobile/desktop social links
- 📦 **Production-ready** build configuration with relative asset paths

---

## 📦 Requirements

- **Node.js 18+** (recommended)
- **npm** or **yarn**

---

## 🚀 Getting Started

1. **Unzip** the downloaded template folder.
2. **Open a terminal** and navigate to the project folder:
   ```bash
   cd html-photography-download
   ```

### 1. Install Dependencies
```bash
npm install
```

### 2. Run the Development Server
```bash
npm run dev
```
Your local dev server will run at `http://localhost:5173` (or the next available port).

### 🏗 Build for Production
```bash
npm run build
```
The optimized production files will be generated in the `dist/` folder.

---

### 🌍 Deployment

This template is configured using relative paths (`base: './'`) for maximum compatibility across hosting environments, including:
- Netlify
- Vercel
- GitHub Pages
- Shared hosting & subfolders

Simply upload the contents of the `dist/` folder to your hosting provider.

---

### 🖼 Images & Assets

All images included in this template are placeholders.

**Important:**
- Replace all placeholder images inside `public/` with your own before publishing.
- Preview images shown in demos are not included unless explicitly stated.
- Do not redistribute placeholder images separately.

---

### 📁 Project Structure

```text
photography/
├── public/               # Static images (served from root "/")
├── src/
│   ├── blog.js           # Blog post data and sidebar renderer
│   ├── main.js           # Menu, hero carousel, lightbox, and parallax scripts
│   └── style.css         # Tailwind CSS import and custom animations
├── index.html            # Main landing page
├── vite.config.js        # Vite build configuration
├── package.json          # Project dependencies and scripts
├── README.md             # Documentation
├── LICENSE.txt           # Commercial license terms
└── THIRD_PARTY_LICENSES.txt
```

---

### 🎨 Customization

- **Page Content & Sections:** Edit `index.html` directly to update text, packages, testimonials, and social links.
- **Blog Posts:** Add or edit articles inside the `posts` array in `src/blog.js`.
- **Styles & Animations:** Customize Tailwind CSS and keyframe animations in `src/style.css`.
- **Images:** Place your photos inside the `public/` folder and reference them from the root (for example, `src="/photo.jpg"`).

---

### 📜 License

This template is licensed under a **Commercial Template License**.

**✔ You may:**
- Use this template for unlimited personal projects
- Use this template for unlimited client projects
- Modify and customize the template

**✘ You may not:**
- Resell or redistribute the template
- Upload the template to public marketplaces or repositories
- Share the source files publicly
- Claim the template as your own original work

See `LICENSE.txt` for full license terms.

### 🧩 ThemeForest Buyers
If this product was purchased via ThemeForest, the Envato Regular License or Extended License applies in accordance with Envato’s terms.

---

### 🆘 Support
For questions, bug reports, or assistance:  
📧 **support@simplewebdesigns.ca**

---

### 💬 Credits
- **Template Design & Development:** AH / simpleWebDesigns
- **Photos:** [Unsplash](https://unsplash.com/)
- **Fonts:** [Google Fonts](https://fonts.google.com/)

---

### 🙌 Thank You
Thank you for purchasing this template. If you find it useful, your support and feedback are greatly appreciated!

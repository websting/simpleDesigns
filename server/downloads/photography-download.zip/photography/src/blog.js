// =====================
// BLOG INIT
// =====================
const blogContent = document.getElementById('blogContent');
const blogList = document.getElementById('blogList');

if (blogContent && blogList) {

  // =====================
  // BLOG POSTS
  // =====================
  const posts = [
    {
      slug: "chasing-golden-hour",
      title: "Chasing Golden Hour",
      date: "September 12, 2025",
      author: "Elena Vance",
      image: "/arco.jpg",
      content: `Natural light shifts minute by minute, turning ordinary architecture into quiet geometry.

      Arriving an hour before sunset gives space to observe how shadows stretch across stone and glass before the camera ever leaves the bag.`
    },
    {
      slug: "portraits-in-silence",
      title: "Portraits in Silence",
      date: "August 28, 2025",
      author: "Elena Vance",
      image: "/trac-vu-bird.jpg",
      content: `Stillness reveals more than motion ever could.

      Portrait photography is about waiting — for light, for breath, for the moment someone forgets the camera is there.`
    }
  ];

  // =====================
  // SIMPLE MARKDOWN PARSER
  // =====================
  function parseMarkdown(md) {
    return md
      .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-bold mt-8 mb-3">$1</h2>')
      .replace(/\n\s*\n/g, '</p><p>');
  }

  // =====================
  // RENDER POST
  // =====================
  function renderPost(post) {
    blogContent.innerHTML = `
      <div class="mb-4 text-neutral-500 text-sm">
        By ${post.author} &middot; ${post.date}
      </div>

      <h3 class="text-3xl md:text-4xl font-bold mb-8 leading-tight text-neutral-900"
          style="font-family: 'Playfair Display', serif;">
        ${post.title}
      </h3>

      <img src="${post.image}" alt="${post.title}" class="w-full max-w-2xl h-80 rounded-lg mb-8 object-cover shadow-md" />

      <div class="text-neutral-800 text-lg leading-relaxed space-y-5 max-w-2xl">
        <p>${parseMarkdown(post.content)}</p>
      </div>
    `;
  }

  // =====================
  // RENDER SIDEBAR
  // =====================
  function renderSidebar(activeSlug) {
    blogList.innerHTML = posts.map(post => {
      const isActive = post.slug === activeSlug;
      return `
        <li>
          <button data-slug="${post.slug}"
            class="text-left w-full p-2.5 -ml-2.5 rounded-md transition ${
              isActive
                ? 'bg-neutral-100 text-neutral-900 font-semibold'
                : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
            }">
            <div>${post.title}</div>
            <div class="text-neutral-400 text-xs mt-1">${post.date}</div>
          </button>
        </li>
      `;
    }).join('');

    blogList.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        const slug = btn.dataset.slug;
        const post = posts.find(p => p.slug === slug);
        if (post) {
          renderPost(post);
          renderSidebar(slug);
          blogContent.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      });
    });
  }

  // =====================
  // INIT
  // =====================
  renderSidebar(posts[0].slug);
  renderPost(posts[0]);
}


